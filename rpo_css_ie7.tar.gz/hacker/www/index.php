<? echo "<p>Hello from stealer!</p>"; ?>
